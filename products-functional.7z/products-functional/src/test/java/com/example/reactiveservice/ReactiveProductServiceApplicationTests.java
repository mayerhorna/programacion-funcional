package com.example.reactiveservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveProductServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
